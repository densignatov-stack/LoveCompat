package com.example.lovecompat

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.InputStream
import java.security.MessageDigest

private enum class Screen { HOME, CALCULATING, RESULT }

private data class CompatibilityResult(
    val score: Int,
    val love: Int,
    val attraction: Int,
    val communication: Int,
    val understanding: Int,
    val emotional: Int
)

private fun sha256(stream: InputStream): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val buffer = ByteArray(8192)
    while (true) {
        val read = stream.read(buffer)
        if (read <= 0) break
        digest.update(buffer, 0, read)
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

private fun hashUri(context: Context, uri: Uri): String {
    return try {
        context.contentResolver.openInputStream(uri)?.use(::sha256) ?: "no-photo"
    } catch (_: Exception) {
        "no-photo"
    }
}

private fun stableScore(
    firstName: String,
    firstPhotoHash: String,
    secondName: String,
    secondPhotoHash: String
): CompatibilityResult {
    val first = firstName.trim().lowercase() + ":" + firstPhotoHash
    val second = secondName.trim().lowercase() + ":" + secondPhotoHash
    val canonical = listOf(first, second).sorted().joinToString("|")
    val bytes = MessageDigest.getInstance("SHA-256")
        .digest(canonical.toByteArray(Charsets.UTF_8))

    var seed = 0L
    for (i in 0 until 8) {
        seed = (seed shl 8) or (bytes[i].toLong() and 0xffL)
    }

    val positive = seed and Long.MAX_VALUE
    val score = (positive % 101L).toInt()

    fun sub(offset: Int, spread: Int): Int {
        val value = ((positive ushr offset) and 0x3fL).toInt()
        val delta = (value % (spread * 2 + 1)) - spread
        return (score + delta).coerceIn(0, 100)
    }

    return CompatibilityResult(
        score = score,
        love = sub(1, 13),
        attraction = sub(7, 15),
        communication = sub(13, 12),
        understanding = sub(19, 14),
        emotional = sub(25, 16)
    )
}

private fun level(score: Int): String = when (score) {
    in 0..19 -> "Очень низкая совместимость"
    in 20..39 -> "Низкая совместимость"
    in 40..59 -> "Средняя совместимость"
    in 60..79 -> "Хорошая совместимость"
    in 80..94 -> "Очень хорошая совместимость"
    else -> "Исключительная совместимость"
}

private fun description(score: Int): String = when (score) {
    in 0..19 -> "По этому развлекательному тесту у вас много различий. Взаимопонимание может требовать больше усилий."
    in 20..39 -> "Результат показывает заметные различия. Хорошее общение здесь особенно важно."
    in 40..59 -> "Есть и совпадения, и различия. Результат находится примерно посередине."
    in 60..79 -> "Тест показывает хороший уровень совпадений и приятный потенциал для общения."
    in 80..94 -> "Много совпадений по параметрам этого теста — сочетание получилось сильным."
    else -> "По параметрам теста совпадений очень много. Получился редкий результат."
}

@Composable
private fun PhotoPicker(uri: Uri?, name: String, onClick: () -> Unit) {
    var photoVisible by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri) {
        photoVisible = false
        if (uri != null) {
            delay(30)
            photoVisible = true
        }
    }

    val photoAlpha by animateFloatAsState(
        targetValue = if (uri != null && photoVisible) 1f else 0f,
        animationSpec = tween(420),
        label = "photoAlpha"
    )
    val photoScale by animateFloatAsState(
        targetValue = if (uri != null && photoVisible) 1f else 0.86f,
        animationSpec = tween(480),
        label = "photoScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(142.dp)
    ) {
        Box(
            modifier = Modifier
                .size(124.dp)
                .clip(CircleShape)
                .background(Color(0xFF252238))
                .border(2.dp, Color(0xFF7E55FF), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (uri != null) {
                AsyncImage(
                    model = uri,
                    contentDescription = name,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            alpha = photoAlpha
                            scaleX = photoScale
                            scaleY = photoScale
                        },
                    contentScale = ContentScale.Crop
                )
            } else {
                Text("＋\nФото", color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun MetricRow(label: String, value: Int) {
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color(0xFFE9E3F1), fontSize = 14.sp)
            Text("$value%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0xFF2A253B))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(value / 100f)
                    .height(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFF4F91), Color(0xFF8B5CF6))
                        )
                    )
            )
        }
    }
}

@Composable
private fun HomeScreen(
    firstName: String,
    onFirstName: (String) -> Unit,
    secondName: String,
    onSecondName: (String) -> Unit,
    firstPhoto: Uri?,
    secondPhoto: Uri?,
    onPickFirst: () -> Unit,
    onPickSecond: () -> Unit,
    error: String,
    onCalculate: () -> Unit
) {
    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        contentPadding = PaddingValues(top = 42.dp, bottom = 30.dp)
    ) {
        item {
            Text("♥", color = Color(0xFFFF4F91), fontSize = 42.sp)
            Spacer(Modifier.height(8.dp))
            Text("LoveCompat", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Тест совместимости для двоих", color = Color(0xFFBDB5CA), fontSize = 14.sp)
            Spacer(Modifier.height(30.dp))

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC171323)),
                border = BorderStroke(1.dp, Color(0xFF342947))
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            PhotoPicker(firstPhoto, if (firstName.isBlank()) "Вы" else firstName, onPickFirst)
                        }
                        Box(
                            Modifier.width(36.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("×", color = Color(0xFFFF4F91), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            PhotoPicker(secondPhoto, if (secondName.isBlank()) "Партнёр" else secondName, onPickSecond)
                        }
                    }

                    Spacer(Modifier.height(22.dp))

                    TextField(
                        value = firstName,
                        onValueChange = onFirstName,
                        singleLine = true,
                        label = { Text("Имя первого человека") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF211C30),
                            unfocusedContainerColor = Color(0xFF211C30),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    Spacer(Modifier.height(12.dp))

                    TextField(
                        value = secondName,
                        onValueChange = onSecondName,
                        singleLine = true,
                        label = { Text("Имя второго человека") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF211C30),
                            unfocusedContainerColor = Color(0xFF211C30),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    if (error.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(error, color = Color(0xFFFF8EA9), fontSize = 13.sp)
                    }

                    Spacer(Modifier.height(20.dp))

                    Button(
                        onClick = onCalculate,
                        modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4F91))
                    ) {
                        Text("♥  Рассчитать совместимость", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "Развлекательный тест. Результат не является научной оценкой отношений.",
                color = Color(0xFF82798F),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
            )
        }
    }
}

@Composable
private fun CalculatingScreen() {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(180.dp)
                .clip(CircleShape)
                .background(Color(0x332D213D)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(92.dp),
                color = Color(0xFFFF4F91),
                strokeWidth = 7.dp
            )
            Text("♥", color = Color.White, fontSize = 38.sp)
        }
        Spacer(Modifier.height(30.dp))
        Text(
            "Считаем вашу совместимость…",
            color = Color.White,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text("Анализируем имена и фотографии", color = Color(0xFFAAA1B6), fontSize = 14.sp)
    }
}

@Composable
private fun ScoreCard(score: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("$score%", fontSize = 58.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF4F91))
            Spacer(Modifier.height(5.dp))
            Text("совместимость", color = Color(0xFFB9B2C8), fontSize = 13.sp)
        }
    }
}

@Composable
private fun ResultScreen(
    first: String,
    second: String,
    firstPhoto: Uri?,
    secondPhoto: Uri?,
    result: CompatibilityResult,
    onBack: () -> Unit,
    onReset: () -> Unit
) {
    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 36.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = onBack, modifier = Modifier.width(100.dp)) { Text("Назад") }
                Spacer(Modifier.width(12.dp))
                Text("Результат", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(Modifier.height(18.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                SmallPhoto(firstPhoto)
                Spacer(Modifier.width(10.dp))
                Text("♥", color = Color(0xFFFF4F91), fontSize = 20.sp)
                Spacer(Modifier.width(10.dp))
                SmallPhoto(secondPhoto)
            }

            Spacer(Modifier.height(8.dp))
            Text("$first  ×  $second", color = Color(0xFFBDB5CA), fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))

            ScoreCard(result.score)
            Spacer(Modifier.height(16.dp))

            Text(level(result.score), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))

            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))) {
                Text(
                    description(result.score),
                    Modifier.padding(20.dp),
                    color = Color(0xFFD7D0DF),
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(20.dp))

            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Параметры", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    MetricRow("♥ Любовь", result.love)
                    MetricRow("🔥 Притяжение", result.attraction)
                    MetricRow("💬 Общение", result.communication)
                    MetricRow("🤝 Понимание", result.understanding)
                    MetricRow("✨ Эмоциональная связь", result.emotional)
                }
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = onReset,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4F91))
            ) {
                Text("Проверить другую пару")
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Один и тот же набор имён и фото даёт один и тот же результат независимо от порядка ввода.",
                color = Color(0xFF756C81),
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SmallPhoto(uri: Uri?) {
    Box(
        Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(0xFF29233A))
            .border(1.dp, Color(0xFF8B5CF6), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (uri != null) {
            AsyncImage(uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("+", color = Color(0xFF9D93AA), fontSize = 20.sp)
        }
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var firstName by remember { mutableStateOf("") }
    var secondName by remember { mutableStateOf("") }
    var firstPhoto by remember { mutableStateOf<Uri?>(null) }
    var secondPhoto by remember { mutableStateOf<Uri?>(null) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var result by remember { mutableStateOf<CompatibilityResult?>(null) }
    var error by remember { mutableStateOf("") }
    var pickerTarget by remember { mutableIntStateOf(1) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (pickerTarget == 1) firstPhoto = uri else secondPhoto = uri
            error = ""
        }
    }

    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            background = Color(0xFF090711),
            surface = Color(0xFF151222),
            primary = Color(0xFFFF4F91),
            secondary = Color(0xFF8B5CF6)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF21152F), Color(0xFF090711), Color(0xFF100B19))
                        )
                    )
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        firstName = firstName,
                        onFirstName = { firstName = it },
                        secondName = secondName,
                        onSecondName = { secondName = it },
                        firstPhoto = firstPhoto,
                        secondPhoto = secondPhoto,
                        onPickFirst = { pickerTarget = 1; picker.launch("image/*") },
                        onPickSecond = { pickerTarget = 2; picker.launch("image/*") },
                        error = error,
                        onCalculate = {
                            if (firstName.isBlank() || secondName.isBlank()) {
                                error = "Введите оба имени"
                                return@HomeScreen
                            }
                            if (firstPhoto == null || secondPhoto == null) {
                                error = "Добавьте две фотографии"
                                return@HomeScreen
                            }
                            error = ""
                            screen = Screen.CALCULATING
                            scope.launch {
                                delay(1800)
                                val hash1 = hashUri(context, firstPhoto!!)
                                val hash2 = hashUri(context, secondPhoto!!)
                                result = stableScore(firstName, hash1, secondName, hash2)
                                screen = Screen.RESULT
                            }
                        }
                    )

                    Screen.CALCULATING -> CalculatingScreen()

                    Screen.RESULT -> result?.let {
                        ResultScreen(
                            first = firstName,
                            second = secondName,
                            firstPhoto = firstPhoto,
                            secondPhoto = secondPhoto,
                            result = it,
                            onBack = { screen = Screen.HOME },
                            onReset = {
                                firstName = ""
                                secondName = ""
                                firstPhoto = null
                                secondPhoto = null
                                result = null
                                error = ""
                                screen = Screen.HOME
                            }
                        )
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
