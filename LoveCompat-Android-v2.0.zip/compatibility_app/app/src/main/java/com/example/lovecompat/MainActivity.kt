package com.example.lovecompat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.InputStream
import java.security.MessageDigest

private enum class Screen { HOME, CALCULATING, RESULT, ABOUT, SUPPORT }
private enum class AppLanguage { RU, EN }

private data class UiText(
    val appSubtitle: String,
    val enterNames: String,
    val firstName: String,
    val secondName: String,
    val calculate: String,
    val entertainment: String,
    val back: String,
    val result: String,
    val compatibility: String,
    val parameters: String,
    val love: String,
    val attraction: String,
    val communication: String,
    val understanding: String,
    val emotional: String,
    val checkAnother: String,
    val deterministic: String,
    val home: String,
    val about: String,
    val support: String,
    val language: String,
    val aboutBody: String,
    val supportBody: String,
    val writeEmail: String,
    val emailUnavailable: String,
    val emailSubject: String,
    val enterBoth: String,
    val addPhotos: String,
    val samePhoto: String,
    val calculationSubtitle: String,
    val aboutVersion: String
)

private val RU = UiText(
    "Тест совместимости для двоих", "Введите имена", "Имя первого человека",
    "Имя второго человека", "♥  Рассчитать совместимость",
    "Развлекательный тест. Результат не является научной оценкой отношений.",
    "Назад", "Результат", "совместимость", "Параметры", "Любовь", "Притяжение",
    "Общение", "Понимание", "Эмоциональная связь", "Проверить другую пару",
    "Один и тот же набор имён и фото даёт один и тот же результат независимо от порядка ввода.",
    "Главная", "О версии", "Поддержка", "Язык",
    "LoveCompat — развлекательный тест совместимости для двоих. Приложение создано для лёгкого и приятного развлечения.",
    "Если у вас есть вопрос или предложение, напишите в службу поддержки.",
    "Написать на почту", "lovecompat.v2.0@gmail.com",
    "LoveCompat — сообщение поддержки", "Введите оба имени", "Добавьте две фотографии",
    "Похоже, выбрана одна и та же фотография для обоих. Пожалуйста, выберите две разные фотографии.",
    "Анализируем имена и фотографии", "Версия 2.0"
)

private val EN = UiText(
    "Compatibility test for two", "Enter names", "First person's name",
    "Second person's name", "♥  Calculate compatibility",
    "Entertainment test. The result is not a scientific assessment of relationships.",
    "Back", "Result", "compatibility", "Parameters", "Love", "Attraction",
    "Communication", "Understanding", "Emotional connection", "Check another pair",
    "The same names and photos always give the same result regardless of input order.",
    "Home", "About", "Support", "Language",
    "LoveCompat is an entertainment compatibility test for two. The app is designed for light and enjoyable fun.",
    "If you have a question or suggestion, contact support.",
    "Write by email", "lovecompat.v2.0@gmail.com",
    "LoveCompat — support message", "Enter both names", "Add two photos",
    "It looks like the same photo was selected for both people. Please choose two different photos.",
    "Analyzing names and photos", "Version 2.0"
)

private fun ui(language: AppLanguage): UiText = if (language == AppLanguage.RU) RU else EN

private data class CompatibilityResult(
    val score: Int,
    val love: Int,
    val attraction: Int,
    val communication: Int,
    val understanding: Int,
    val emotional: Int
)

private fun sha256(stream: InputStream): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val buffer = ByteArray(8192)
    while (true) {
        val read = stream.read(buffer)
        if (read <= 0) break
        digest.update(buffer, 0, read)
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

private fun hashUri(context: Context, uri: Uri): String {
    return try {
        context.contentResolver.openInputStream(uri)?.use(::sha256) ?: "no-photo"
    } catch (_: Exception) {
        "no-photo"
    }
}

private fun stableScore(
    firstName: String,
    firstPhotoHash: String,
    secondName: String,
    secondPhotoHash: String
): CompatibilityResult {
    // Для расчёта используем только буквы и цифры:
    // регистр, пробелы, ❤️ и другие декоративные символы не меняют результат.
    fun normalizeName(name: String): String =
        name.lowercase().filter { it.isLetterOrDigit() }

    val first = normalizeName(firstName) + ":" + firstPhotoHash
    val second = normalizeName(secondName) + ":" + secondPhotoHash
    val canonical = listOf(first, second).sorted().joinToString("|")
    val bytes = MessageDigest.getInstance("SHA-256")
        .digest(canonical.toByteArray(Charsets.UTF_8))

    var seed = 0L
    for (i in 0 until 8) {
        seed = (seed shl 8) or (bytes[i].toLong() and 0xffL)
    }

    val positive = seed and Long.MAX_VALUE
    val score = (positive % 101L).toInt()

    fun sub(offset: Int, spread: Int): Int {
        val value = ((positive ushr offset) and 0x3fL).toInt()
        val delta = (value % (spread * 2 + 1)) - spread
        return (score + delta).coerceIn(0, 100)
    }

    return CompatibilityResult(
        score = score,
        love = sub(1, 13),
        attraction = sub(7, 15),
        communication = sub(13, 12),
        understanding = sub(19, 14),
        emotional = sub(25, 16)
    )
}

private fun level(score: Int, language: AppLanguage): String = if (language == AppLanguage.RU) when (score) {
    in 0..19 -> "Очень низкая совместимость"
    in 20..39 -> "Низкая совместимость"
    in 40..59 -> "Средняя совместимость"
    in 60..79 -> "Хорошая совместимость"
    in 80..94 -> "Очень хорошая совместимость"
    else -> "Исключительная совместимость"
} else when (score) {
    in 0..19 -> "Very low compatibility"
    in 20..39 -> "Low compatibility"
    in 40..59 -> "Average compatibility"
    in 60..79 -> "Good compatibility"
    in 80..94 -> "Very good compatibility"
    else -> "Exceptional compatibility"
}

private fun description(score: Int, language: AppLanguage): String = if (language == AppLanguage.RU) when (score) {
    in 0..19 -> "По этому развлекательному тесту у вас много различий. Взаимопонимание может требовать больше усилий."
    in 20..39 -> "Результат показывает заметные различия. Хорошее общение здесь особенно важно."
    in 40..59 -> "Есть и совпадения, и различия. Результат находится примерно посередине."
    in 60..79 -> "Тест показывает хороший уровень совпадений и приятный потенциал для общения."
    in 80..94 -> "Много совпадений по параметрам этого теста — сочетание получилось сильным."
    else -> "По параметрам теста совпадений очень много. Получился редкий результат."
} else when (score) {
    in 0..19 -> "This entertainment test shows many differences. Understanding each other may require more effort."
    in 20..39 -> "The result shows noticeable differences. Good communication is especially important here."
    in 40..59 -> "There are both similarities and differences. The result is around the middle."
    in 60..79 -> "The test shows a good level of similarities and pleasant potential for communication."
    in 80..94 -> "There are many matches across the test parameters — the combination turned out strong."
    else -> "There are very many matches across the test parameters. This is a rare result."
}

@Composable
private fun PhotoPicker(uri: Uri?, name: String, language: AppLanguage, onClick: () -> Unit) {
    var photoVisible by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri) {
        photoVisible = false
        if (uri != null) {
            delay(30)
            photoVisible = true
        }
    }

    val photoAlpha by animateFloatAsState(
        targetValue = if (uri != null && photoVisible) 1f else 0f,
        animationSpec = tween(420),
        label = "photoAlpha"
    )
    val photoScale by animateFloatAsState(
        targetValue = if (uri != null && photoVisible) 1f else 0.86f,
        animationSpec = tween(480),
        label = "photoScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(112.dp)
    ) {
        Box(
            modifier = Modifier
                .size(112.dp)
                .clip(CircleShape)
                .background(Color(0xFF252238))
                .border(2.dp, Color(0xFF7E55FF), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (uri != null) {
                AsyncImage(
                    model = uri,
                    contentDescription = name,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            alpha = photoAlpha
                            scaleX = photoScale
                            scaleY = photoScale
                        },
                    contentScale = ContentScale.Crop
                )
            } else {
                Text(if (language == AppLanguage.RU) "＋\nФото" else "＋\nPhoto", color = Color.White, fontSize = 17.sp, textAlign = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun MetricRow(label: String, value: Int) {
    var animatedValue by remember(value) { mutableIntStateOf(0) }

    LaunchedEffect(value) {
        val duration = 2600L
        val steps = 65
        val stepDelay = duration / steps
        for (i in 1..steps) {
            animatedValue = (value * i / steps)
            delay(stepDelay)
        }
        animatedValue = value
    }

    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color(0xFFE9E3F1), fontSize = 14.sp)
            Text("$animatedValue%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0xFF2A253B))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(animatedValue / 100f)
                    .height(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFF4F91), Color(0xFF8B5CF6))
                        )
                    )
            )
        }
    }
}

@Composable
private fun FloatingEmojiLayer() {
    val emojis = listOf("♥", "💕", "💖", "✨", "😍", "🥰", "💗", "💘", "💝", "💫", "🌸", "❤️", "💞", "😘", "⭐")
    Box(Modifier.fillMaxSize()) {
        emojis.forEachIndexed { index, emoji ->
            FloatingEmoji(emoji = emoji, index = index)
        }
    }
}

@Composable
private fun FloatingEmoji(emoji: String, index: Int) {
    val density = LocalDensity.current
    val startX = with(density) { (12 + (index * 83) % 350).dp.toPx() }
    val startY = with(density) { (780 + (index % 5) * 145).dp.toPx() }
    val endY = with(density) { (-100).dp.toPx() }
    val horizontalDrift = with(density) {
        when (index % 6) {
            0 -> 145f
            1 -> -165f
            2 -> 105f
            3 -> -125f
            4 -> 175f
            else -> -95f
        }
    }
    val y = remember { Animatable(startY) }
    val x = remember { Animatable(startX) }
    val rotation = remember { Animatable(0f) }

    LaunchedEffect(index) {
        delay(index * 280L)
        while (true) {
            y.snapTo(startY)
            x.snapTo(startX)
            rotation.snapTo(0f)
            val duration = 6800 + (index % 5) * 850
            kotlinx.coroutines.coroutineScope {
                launch { y.animateTo(endY, tween(duration, easing = androidx.compose.animation.core.LinearEasing)) }
                launch { x.animateTo(startX + horizontalDrift, tween(duration, easing = androidx.compose.animation.core.LinearEasing)) }
                launch { rotation.animateTo(if (index % 2 == 0) 18f else -18f, tween(duration, easing = androidx.compose.animation.core.LinearEasing)) }
            }
            delay(220L)
        }
    }

    val progress = ((startY - y.value) / (startY - endY)).coerceIn(0f, 1f)
    val fadeIn = (progress / 0.10f).coerceIn(0f, 1f)
    val fadeOut = ((1f - progress) / 0.14f).coerceIn(0f, 1f)

    Text(
        text = emoji,
        fontSize = (20 + (index % 5) * 5).sp,
        modifier = Modifier.graphicsLayer {
            translationX = x.value
            translationY = y.value
            rotationZ = rotation.value
            alpha = 0.46f * fadeIn * fadeOut
        }
    )
}

@Composable
private fun HomeScreen(
    language: AppLanguage,
    firstName: String,
    onFirstName: (String) -> Unit,
    secondName: String,
    onSecondName: (String) -> Unit,
    firstPhoto: Uri?,
    secondPhoto: Uri?,
    onPickFirst: () -> Unit,
    onPickSecond: () -> Unit,
    error: String,
    onCalculate: () -> Unit,
    menuOpen: Boolean,
    onMenuToggle: () -> Unit,
    onAbout: () -> Unit,
    onSupport: () -> Unit,
    onLanguageToggle: () -> Unit
) {
    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        contentPadding = PaddingValues(top = 42.dp, bottom = 30.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Color(0xCC171323))
                        .border(1.dp, Color(0xFF6D5A88), CircleShape)
                        .clickable(onClick = onMenuToggle),
                    contentAlignment = Alignment.Center
                ) { Text("☰", color = Color.White, fontSize = 21.sp) }

                Text("♥", color = Color(0xFFFF4F91), fontSize = 42.sp)

                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Color(0xCC171323))
                        .border(1.dp, Color(0xFF6D5A88), CircleShape)
                        .clickable(onClick = onLanguageToggle),
                    contentAlignment = Alignment.Center
                ) { Text("文", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            if (menuOpen) {
                Spacer(Modifier.height(10.dp))
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xF0181323)),
                    border = BorderStroke(1.dp, Color(0xFF342947))
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Text(ui(language).about, color = Color.White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().padding(16.dp).clickable(onClick = onAbout))
                        Text(ui(language).support, color = Color.White, fontSize = 16.sp, modifier = Modifier.fillMaxWidth().padding(16.dp).clickable(onClick = onSupport))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("LoveCompat", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(ui(language).appSubtitle, color = Color(0xFFBDB5CA), fontSize = 14.sp)
            Spacer(Modifier.height(30.dp))

            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xCC171323)),
                border = BorderStroke(1.dp, Color(0xFF342947))
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            PhotoPicker(firstPhoto, if (firstName.isBlank()) (if (language == AppLanguage.RU) "Вы" else "You") else firstName, language, onPickFirst)
                        }
                        Box(
                            Modifier
                                .width(36.dp)
                                .padding(bottom = 28.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("×", color = Color(0xFFFF4F91), fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            PhotoPicker(secondPhoto, if (secondName.isBlank()) (if (language == AppLanguage.RU) "Партнёр" else "Partner") else secondName, language, onPickSecond)
                        }
                    }

                    Spacer(Modifier.height(22.dp))

                    Text(
                        ui(language).enterNames,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))

                    TextField(
                        value = firstName,
                        onValueChange = onFirstName,
                        singleLine = true,
                        label = { Text(ui(language).firstName) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF211C30),
                            unfocusedContainerColor = Color(0xFF211C30),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    Spacer(Modifier.height(12.dp))

                    TextField(
                        value = secondName,
                        onValueChange = onSecondName,
                        singleLine = true,
                        label = { Text(ui(language).secondName) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF211C30),
                            unfocusedContainerColor = Color(0xFF211C30),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )

                    if (error.isNotBlank()) {
                        Spacer(Modifier.height(10.dp))
                        Text(error, color = Color(0xFFFF8EA9), fontSize = 13.sp)
                    }

                    Spacer(Modifier.height(20.dp))

                    Button(
                        onClick = onCalculate,
                        modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4F91))
                    ) {
                        Text(ui(language).calculate, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                ui(language).entertainment,
                color = Color(0xFF82798F),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)
            )
        }
    }
}

@Composable
private fun CalculatingScreen(language: AppLanguage) {
    var step by remember { mutableIntStateOf(0) }
    var pulseTarget by remember { mutableStateOf(0.92f) }
    var rotation by remember { mutableStateOf(0f) }

    val pulse by animateFloatAsState(
        targetValue = pulseTarget,
        animationSpec = tween(1500),
        label = "calculationPulse"
    )

    val steps = if (language == AppLanguage.RU) listOf(
        "Настраиваем связь…", "Сравниваем характеры…", "Ищем совпадения…",
        "Проверяем взаимопонимание…", "Анализируем притяжение…",
        "Сверяем ваши параметры…", "Почти готово…", "Формируем результат…"
    ) else listOf(
        "Connecting…", "Comparing personalities…", "Looking for matches…",
        "Checking understanding…", "Analyzing attraction…",
        "Comparing your parameters…", "Almost ready…", "Preparing the result…"
    )

    LaunchedEffect(Unit) {
        // Показываем все 8 сообщений по очереди.
        // Весь экран расчёта длится столько же, сколько нужно для прохождения всех фраз.
        repeat(steps.size - 1) {
            delay(1450)
            step += 1
            pulseTarget = if (pulseTarget > 1f) 0.92f else 1.08f
            rotation += 60f
        }
    }

    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(180.dp)
                .graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                }
                .clip(CircleShape)
                .background(Color(0x332D213D)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                modifier = Modifier
                    .size(112.dp)
                    .graphicsLayer { rotationZ = rotation },
                color = Color(0xFFFF4F91),
                strokeWidth = 7.dp
            )
            Text("♥", color = Color.White, fontSize = 38.sp)
        }
        Spacer(Modifier.height(30.dp))
        Text(
            steps[step],
            color = Color.White,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            ui(language).calculationSubtitle,
            color = Color(0xFFAAA1B6),
            fontSize = 14.sp
        )
    }
}

@Composable
private fun ScoreCard(score: Int, visible: Boolean, language: AppLanguage) {
    var animatedScore by remember(score, visible) { mutableIntStateOf(0) }

    LaunchedEffect(score, visible) {
        if (!visible) {
            animatedScore = 0
            return@LaunchedEffect
        }

        val duration = 3000L
        val steps = 75
        val stepDelay = duration / steps
        for (i in 1..steps) {
            animatedScore = (score * i / steps)
            delay(stepDelay)
        }
        animatedScore = score
    }

    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(520),
        label = "scoreAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.82f,
        animationSpec = tween(650),
        label = "scoreScale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("$animatedScore%", fontSize = 58.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF4F91))
            Spacer(Modifier.height(5.dp))
            Text(ui(language).compatibility, color = Color(0xFFB9B2C8), fontSize = 13.sp)
        }
    }
}

@Composable
private fun AnimatedResultItem(
    visible: Boolean,
    content: @Composable () -> Unit
) {
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(500),
        label = "resultAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.94f,
        animationSpec = tween(560),
        label = "resultScale"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            }
    ) {
        content()
    }
}

@Composable
private fun ResultMetricRow(label: String, value: Int, visible: Boolean) {
    var animatedValue by remember(value, visible) { mutableIntStateOf(0) }

    LaunchedEffect(value, visible) {
        if (!visible) {
            animatedValue = 0
            return@LaunchedEffect
        }

        val duration = 1050L
        val steps = 35
        val stepDelay = duration / steps
        for (i in 1..steps) {
            animatedValue = (value * i / steps)
            delay(stepDelay)
        }
        animatedValue = value
    }

    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(450),
        label = "metricAlpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.96f,
        animationSpec = tween(500),
        label = "metricScale"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp)
            .graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            }
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color(0xFFE9E3F1), fontSize = 14.sp)
            Text("$animatedValue%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(50))
                .background(Color(0xFF2A253B))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(animatedValue / 100f)
                    .height(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFF4F91), Color(0xFF8B5CF6))
                        )
                    )
            )
        }
    }
}

@Composable
private fun ResultScreen(
    language: AppLanguage,
    first: String,
    second: String,
    firstPhoto: Uri?,
    secondPhoto: Uri?,
    result: CompatibilityResult,
    onBack: () -> Unit,
    onReset: () -> Unit
) {
    var stage by remember { mutableIntStateOf(0) }

    LaunchedEffect(result) {
        stage = 0
        delay(250)
        stage = 1
        delay(500)
        stage = 2
        delay(450)
        stage = 3
        delay(450)
        stage = 4
        delay(500)
        stage = 5
        delay(500)
        stage = 6
        delay(500)
        stage = 7
        delay(500)
        stage = 8
        delay(500)
        stage = 9
        delay(650)
        stage = 10
    }

    LazyColumn(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 36.dp)
    ) {
        item {
            AnimatedResultItem(stage >= 1) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = onBack, modifier = Modifier.width(100.dp)) { Text(ui(language).back) }
                    Spacer(Modifier.width(12.dp))
                    Text(ui(language).result, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Spacer(Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SmallPhoto(firstPhoto)
                    Spacer(Modifier.width(14.dp))
                    Text("♥", color = Color(0xFFFF4F91), fontSize = 26.sp)
                    Spacer(Modifier.width(14.dp))
                    SmallPhoto(secondPhoto)
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    "$first  ×  $second",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(18.dp))

            ScoreCard(result.score, stage >= 2, language)
            Spacer(Modifier.height(16.dp))

            AnimatedResultItem(stage >= 3) {
                Text(
                    level(result.score, language),
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(10.dp))

            AnimatedResultItem(stage >= 4) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))
                ) {
                    Text(
                        description(result.score, language),
                        Modifier.padding(20.dp),
                        color = Color(0xFFD7D0DF),
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            AnimatedResultItem(stage >= 5) {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text(ui(language).parameters, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        ResultMetricRow("♥ ${ui(language).love}", result.love, stage >= 5)
                        ResultMetricRow("🔥 ${ui(language).attraction}", result.attraction, stage >= 6)
                        ResultMetricRow("💬 ${ui(language).communication}", result.communication, stage >= 7)
                        ResultMetricRow("🤝 ${ui(language).understanding}", result.understanding, stage >= 8)
                        ResultMetricRow("✨ ${ui(language).emotional}", result.emotional, stage >= 9)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            AnimatedResultItem(stage >= 10) {
                Button(
                    onClick = onReset,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4F91))
                ) {
                    Text(ui(language).checkAnother)
                }

            }
        }
    }
}

@Composable
private fun InfoScreen(title: String, body: String, language: AppLanguage, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack, modifier = Modifier.width(100.dp)) { Text(ui(language).back) }
            Spacer(Modifier.width(12.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(28.dp))
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))
        ) {
            Text(body, Modifier.padding(22.dp), color = Color(0xFFD7D0DF), fontSize = 16.sp, lineHeight = 24.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun SupportScreen(language: AppLanguage, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack, modifier = Modifier.width(100.dp)) { Text(ui(language).back) }
            Spacer(Modifier.width(12.dp))
            Text(ui(language).support, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(28.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xCC171323))) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(ui(language).supportBody, color = Color(0xFFD7D0DF), fontSize = 16.sp, lineHeight = 24.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:lovecompat.v2.0@gmail.com")
                            putExtra(Intent.EXTRA_SUBJECT, ui(language).emailSubject)
                        }
                        try { context.startActivity(intent) } catch (_: Exception) { }
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4F91))
                ) { Text(ui(language).writeEmail) }
                Spacer(Modifier.height(12.dp))
                Text("lovecompat.v2.0@gmail.com", color = Color(0xFF8E8499), fontSize = 11.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun SmallPhoto(uri: Uri?) {
    Box(
        Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(0xFF29233A))
            .border(1.dp, Color(0xFF8B5CF6), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (uri != null) {
            AsyncImage(uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("+", color = Color(0xFF9D93AA), fontSize = 20.sp)
        }
    }
}

@Composable
private fun App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var firstName by remember { mutableStateOf("") }
    var secondName by remember { mutableStateOf("") }
    var firstPhoto by remember { mutableStateOf<Uri?>(null) }
    var secondPhoto by remember { mutableStateOf<Uri?>(null) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var result by remember { mutableStateOf<CompatibilityResult?>(null) }
    var error by remember { mutableStateOf("") }
    var pickerTarget by remember { mutableIntStateOf(1) }
    var menuOpen by remember { mutableStateOf(false) }
    var language by remember {
        val saved = context.getSharedPreferences("lovecompat", Context.MODE_PRIVATE).getString("language", "RU")
        mutableStateOf(if (saved == "EN") AppLanguage.EN else AppLanguage.RU)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (pickerTarget == 1) firstPhoto = uri else secondPhoto = uri
            error = ""
        }
    }

    fun toggleLanguage() {
        language = if (language == AppLanguage.RU) AppLanguage.EN else AppLanguage.RU
        context.getSharedPreferences("lovecompat", Context.MODE_PRIVATE).edit()
            .putString("language", language.name).apply()
    }

    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            background = Color(0xFF090711), surface = Color(0xFF151222),
            primary = Color(0xFFFF4F91), secondary = Color(0xFF8B5CF6)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
            Box(
                Modifier.fillMaxSize().systemBarsPadding().background(
                    Brush.verticalGradient(listOf(Color(0xFF21152F), Color(0xFF090711), Color(0xFF100B19)))
                )
            ) {
                FloatingEmojiLayer()
                Crossfade(targetState = screen, label = "screenTransition") { currentScreen ->
                    when (currentScreen) {
                        Screen.HOME -> HomeScreen(
                            language = language, firstName = firstName, onFirstName = { firstName = it },
                            secondName = secondName, onSecondName = { secondName = it },
                            firstPhoto = firstPhoto, secondPhoto = secondPhoto,
                            onPickFirst = { pickerTarget = 1; picker.launch("image/*") },
                            onPickSecond = { pickerTarget = 2; picker.launch("image/*") },
                            error = error, menuOpen = menuOpen, onMenuToggle = { menuOpen = !menuOpen },
                            onAbout = { menuOpen = false; screen = Screen.ABOUT },
                            onSupport = { menuOpen = false; screen = Screen.SUPPORT },
                            onLanguageToggle = ::toggleLanguage,
                            onCalculate = {
                                if (firstName.isBlank() || secondName.isBlank()) { error = ui(language).enterBoth; return@HomeScreen }
                                if (firstPhoto == null || secondPhoto == null) { error = ui(language).addPhotos; return@HomeScreen }
                                val hash1 = hashUri(context, firstPhoto!!)
                                val hash2 = hashUri(context, secondPhoto!!)
                                if (hash1 == hash2) {
                                    error = ui(language).samePhoto
                                    return@HomeScreen
                                }
                                error = ""
                                screen = Screen.CALCULATING
                                scope.launch {
                                    delay(11800)
                                    result = stableScore(firstName, hash1, secondName, hash2)
                                    screen = Screen.RESULT
                                }
                            }
                        )
                        Screen.CALCULATING -> CalculatingScreen(language)
                        Screen.RESULT -> result?.let { r ->
                            ResultScreen(language, firstName, secondName, firstPhoto, secondPhoto, r,
                                onBack = { screen = Screen.HOME },
                                onReset = { firstName = ""; secondName = ""; firstPhoto = null; secondPhoto = null; result = null; error = ""; screen = Screen.HOME })
                        }
                        Screen.ABOUT -> InfoScreen(
                            ui(language).about,
                            if (language == AppLanguage.RU) {
                                "Версия 2.0\n\nЧто нового в 2.0\n\n• Плавные переходы и анимации\n• Плавающие яркие смайлики на фоне\n• Русский и английский языки\n• Обновлённый главный экран\n• Проверка на одинаковые фотографии\n• Улучшенная структура приложения\n\nLoveCompat создан для лёгкого и приятного развлечения."
                            } else {
                                "Version 2.0\n\nWhat’s new in 2.0\n\n• Smooth transitions and animations\n• Bright floating emojis in the background\n• Russian and English languages\n• Updated home screen\n• Duplicate-photo check\n• Improved app structure\n\nLoveCompat is made for light and enjoyable fun."
                            },
                            language
                        ) { screen = Screen.HOME }
                        Screen.SUPPORT -> SupportScreen(language) { screen = Screen.HOME }
                    }
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
