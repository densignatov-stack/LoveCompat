# LoveCompat Android v1.0 — Cloud Build

This is the Android v1.0 test build of LoveCompat.

## Build APK from a phone with GitHub

1. Create a new GitHub repository (public or private).
2. Upload **all files and folders inside this folder** to the repository, keeping the folder structure.
3. Open **Actions** → **Build LoveCompat APK**.
4. If GitHub asks to enable workflows, enable Actions.
5. Run the workflow with **Run workflow** (or push to `main`/`master`).
6. Open the completed workflow run and download the artifact named **LoveCompat-v1.0-debug-apk**.
7. Extract the downloaded artifact and install `app-debug.apk` on Android.

The app is an entertainment-style compatibility test. Results are deterministic and order-independent for the same pair of names/photos.


## Version 1.1
- Added launcher icon.
- Added animated photo selection/change transition.
